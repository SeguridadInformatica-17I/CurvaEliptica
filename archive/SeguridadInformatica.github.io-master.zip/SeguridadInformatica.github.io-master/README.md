## Seguridad Informática

### Tema de Investigación

Criptografía de curva

* Criptosistema

* Definiciónes Previas
  - Cuerpo
  - Grupo
  - Característica de un Cuerpo

* Introduccion
