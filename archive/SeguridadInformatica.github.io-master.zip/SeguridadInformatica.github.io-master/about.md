---
layout: page
title: About
---

* Criptosistema

* Definiciónes Previas
  1. Cuerpo
  2. Grupo

* Introducción
  * Curva Elíptica
  * Curvas Elipticas Aleatorias

* Aritmética Geométrica

* Diffie-Hellman con curva elı́ptica
  * Algoritmo
  * Ejemplo
  * Key encrypion y key  MAC
